# Standard Libraries
import re
import asyncio
import psycopg2
from datetime import datetime
from dataclasses import dataclass
from typing import List

# First Party Libraries
from .database import DatabaseOperations

@dataclass
class VideoFile:
    video_file_id: int
    local_path: str

class ExtendedDatabaseOperations(DatabaseOperations):
    def get_local_paths_to_update(self) -> List[VideoFile]:
        """
        Retrieves a list of video_file_id and local_path tuples from the yt_video_file table
        where local_path is not null and does not contain the pattern '{e-'.

        Returns:
            List[VideoFile]: A list of VideoFile dataclass instances.
        
        Raises:
            psycopg2.Error: If an SQL error occurs.
        """
        try:
            with DatabaseOperations.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    # Define the SQL query with parameterized ILIKE
                    query = """
                        SELECT vf.video_file_id, vf.local_path, md.channel_title
                        FROM yt_video_file vf
                        JOIN yt_metadata md ON md.video_id = vf.video_id
                        WHERE TRUE
                            AND vf.local_path IS NOT NULL
                            AND vf.local_path NOT ILIKE '%{e-%'
                            AND vf.video_id = 'cV-5TS3nmSc'
                        ORDER BY vf.video_file_id
                    """
                    
                    cursor.execute(query)
                    results = cursor.fetchall()  # Fetch all results
                    
                    # Create a list of VideoFile instances
                    video_files = [VideoFile(video_file_id=row[0], local_path=row[1]) for row in results]
                    
                conn.commit()
                
            print(f"Retrieved {len(video_files)} video files.")
            return video_files
            
        except psycopg2.Error as e:
            print(f"SQL Error when retrieving video file information: {e}")
            raise  # Re-raise the exception for the caller to handle

@dataclass
class AudioFileInfo:
    date_prefix: str
    away_team: str
    home_team: str
    filename_date: str
    # language: str
    # duration_string: int
    # asr: int
    # dynamic_range: str
    # acodec: str
    # quality: float
    # format_note: str
    # format_id: int
    # video_id: str
    before_eid: str
    after_eid: str

@dataclass
class AudioFileInfo:
    date_prefix: str
    away_team: str
    home_team: str
    filename_date: str
    language: str
    duration_string: int
    asr: int
    dynamic_range: str
    acodec: str
    quality: float
    format_note: str
    format_id: str
    video_id: str

    @classmethod
    def from_string(cls, s: str):
        pattern = re.compile(
            r'^(?P<date_prefix>[\d/]+|unknown_date)/'
            r'(?P<away_team>\w+) at (?P<home_team>\w+) - '
            r'(?P<filename_date>[\d.]+) - '
            r'\[(?P<language>\w+)\]\['
            r'(?P<duration_string>\d+)\]\['
            r'(?P<asr>\d+)\]\['
            r'(?P<dynamic_range>[^\]]+)\]\['
            r'(?P<acodec>[^\]]+)\]\['
            r'(?P<quality>[^\]]+)\]\['
            r'(?P<format_note>[^\]]+)\]'
            r'\{fid-(?P<format_id>\d+)\}'
            r'\{yt-(?P<video_id>[A-Za-z0-9_-]+)\}\.m4a$'
        )
        match = pattern.match(s)
        if not match:
            raise ValueError(f"String does not match pattern: {s}")
        data = match.groupdict()
        return cls(
            date_prefix=data['date_prefix'],
            away_team=data['away_team'],
            home_team=data['home_team'],
            filename_date=data['filename_date'],
            language=data['language'],
            duration_string=int(data['duration_string']),
            asr=int(data['asr']),
            dynamic_range=data['dynamic_range'],
            acodec=data['acodec'],
            quality=float(data['quality']),
            format_note=data['format_note'],
            format_id=int(data['format_id']),
            video_id=data['video_id']
        )
        
async def main():
    db_ops = ExtendedDatabaseOperations()
    # sdb = stubdb()
    
    # Retrieve the list of video_file_ids and local_paths to update
    video_files = db_ops.get_local_paths_to_update()
        
    updates = []
    
    for video_file in video_files:
        if 'unknown_date' in video_file.local_path:
            print(f"Skipping {video_file.video_file_id}: Date unknown.")
            continue
        if 'unknown at unknown' in video_file.local_path:
            print(f"Skipping {video_file.video_file_id}: No known teams.")
            continue
        try:
            audio_info = AudioFileInfo.from_string(video_file.local_path)
            print(f"Attempting {video_file.video_file_id}.")
            print(f"Parsed Audio Info: {audio_info}")
        except ValueError:
            print(f"Skipping {video_file.video_file_id}: Failed to parse local_path.")
            continue  # Skip if parsing fails
        try:
            date_obj = datetime.strptime(audio_info.filename_date, '%Y.%m.%d').date()
            print(f"Original Date: {date_obj}")
        except ValueError:
            print(f"Skipping {video_file.video_file_id}: Invalid date format '{audio_info.filename_date}'.")
            continue  # Skip if date parsing fails
        
        # First attempt to retrieve the e_event_id with the original date
        e_event_id = db_ops.get_event_id(date_obj, audio_info.home_team, audio_info.away_team)
        print(f"Attempting {video_file.video_file_id} with original date.")
        print(f"Attempt 1 - e_event_id: {e_event_id}")
        
        # If e_event_id is not found, swap month and day and try again
        if not e_event_id:
            print("e_event_id not found with original date. Attempting to swap month and day.")
            swapped_date_str = audio_info.filename_date.split('.')
            if len(swapped_date_str) == 3:
                year, month, day = swapped_date_str
                swapped_date_str = f"{year}.{day}.{month}"
                swapped_date_path = f"{year}/{day}/{month}"
                try:
                    swapped_date_obj = datetime.strptime(swapped_date_str, '%Y.%m.%d').date()
                    print(f"Swapped Date: {swapped_date_obj}")
                except ValueError:
                    print(f"Skipping {video_file.video_file_id}: Invalid swapped date format '{swapped_date_str}'.")
                    continue  # Skip if swapped date parsing fails
                
                # Attempt to retrieve e_event_id with the swapped date
                e_event_id = db_ops.get_event_id(swapped_date_obj, audio_info.home_team, audio_info.away_team)
                print(f"Attempt 2 - e_event_id: {e_event_id}")
                
                if e_event_id:
                    # Update the date_obj and possibly the filename_date if needed
                    date_obj = swapped_date_obj
                    audio_info.date_prefix = swapped_date_path
                    audio_info.filename_date = swapped_date_str
                else:
                    print(f"Skipping {video_file.video_file_id}: e_event_id not found even after swapping date.")
                    continue  # Skip if e_event_id is still not found
            else:
                print(f"Skipping {video_file.video_file_id}: Unexpected date format '{audio_info.filename_date}'.")
                continue  # Skip if the date doesn't have exactly 3 components

        # Construct the new local path with the retrieved e_event_id
        new_local_path = (
            f"{audio_info.date_prefix}/"
            f"{audio_info.away_team} at {audio_info.home_team} - {audio_info.filename_date} - "
            f"[{audio_info.language}][{audio_info.duration_string}][{audio_info.asr}][{audio_info.dynamic_range}]"
            f"[{audio_info.acodec}][{audio_info.quality}][{audio_info.format_note}]"
            f"{{fid-{audio_info.format_id}}}"
            f"{{e-{e_event_id}}}"
            f"{{yt-{audio_info.video_id}}}.m4a"
        )
        updates.append({
            'video_file_id': video_file.video_file_id,
            'new_local_path': new_local_path
        })
        print(f"Updated {video_file.video_file_id}:\n{video_file.local_path} ->\n{new_local_path}")
    
    # Perform bulk update if there are any updates
    if updates:
        # await db_ops.bulk_update_local_paths(updates)
        print(f"Bulk updated {len(updates)} local paths.")
    else:
        print("No updates to perform.")

if __name__ == "__main__":
    # Run the main function with the provided prompt
    asyncio.run(main())

# Run the script as a Module:
# python -m yt_dlp_async.backfill_ids
